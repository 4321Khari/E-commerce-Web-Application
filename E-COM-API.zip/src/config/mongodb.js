import { MongoClient } from "mongodb";


let client;
export const connectToMongodb = ()=>{
    MongoClient.connect(process.env.DB_URL)
    .then(clientInstance=>{
        client = clientInstance;
        console.log("connected to DB");
        //modifying _id
        createCounter(client.db())
    })
    .catch(err=>{
        console.log(err);
    })
}

export const getDB = ()=>{
    return client.db();

};

 //modifying _id
const createCounter = async(db)=>{
    const existingCounter = await db.collection("counters").findOne({_id:"cartItemID"});
    if(!existingCounter){
        await db.collection("counters").insertOne({_id:"cartItemID",value:0});

    }
}